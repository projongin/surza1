/*
 * File: MYD_types.h
 *
 * Code generated for Simulink model 'MYD'.
 *
 * Model version                  : 1.747
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Thu Sep 13 09:31:32 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_MYD_types_h_
#define RTW_HEADER_MYD_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_MYD_T RT_MODEL_MYD_T;

#endif                                 /* RTW_HEADER_MYD_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
