/*
 * File: MYD_data.c
 *
 * Code generated for Simulink model 'MYD'.
 *
 * Model version                  : 1.747
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Thu Sep 13 09:31:32 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "MYD.h"
#include "MYD_private.h"

/* Constant parameters (auto storage) */
const ConstP_MYD_T MYD_ConstP = {
  /* Computed Parameter: Constant_Value
   * Referenced by: '<S2>/Constant'
   */
  { 0U, 2147483648U, 2863311531U, 715827883U, 1431655765U, 3579139413U }
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
