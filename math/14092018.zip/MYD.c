/*
 * File: MYD.c
 *
 * Code generated for Simulink model 'MYD'.
 *
 * Model version                  : 1.747
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Thu Sep 13 09:31:32 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "MYD.h"
#include "MYD_private.h"

/* Named constants for Chart: '<S4>/Chart1' */
#define MYD_IN_Imp_positioner          ((uint8_T)1U)
#define MYD_IN_NO_ACTIVE_CHILD         ((uint8_T)0U)
#define MYD_IN_comm                    ((uint8_T)1U)
#define MYD_IN_start_work              ((uint8_T)2U)
#define MYD_IN_wait_comm               ((uint8_T)3U)
#define MYD_IN_wait_st_per             ((uint8_T)4U)

/* Block signals (auto storage) */
B_MYD_T MYD_B;

/* Block states (auto storage) */
DW_MYD_T MYD_DW;

/* External inputs (root inport signals with auto storage) */
ExtU_MYD_T MYD_U;

/* External outputs (root outports fed by signals with auto storage) */
ExtY_MYD_T MYD_Y;

/* Real-time model */
RT_MODEL_MYD_T MYD_M_;
RT_MODEL_MYD_T *const MYD_M = &MYD_M_;
void mul_wide_s32(int32_T in0, int32_T in1, uint32_T *ptrOutBitsHi, uint32_T
                  *ptrOutBitsLo)
{
  uint32_T absIn0;
  uint32_T absIn1;
  uint32_T in0Lo;
  uint32_T in0Hi;
  uint32_T in1Hi;
  uint32_T productHiLo;
  uint32_T productLoHi;
  absIn0 = in0 < 0 ? ~(uint32_T)in0 + 1U : (uint32_T)in0;
  absIn1 = in1 < 0 ? ~(uint32_T)in1 + 1U : (uint32_T)in1;
  in0Hi = absIn0 >> 16U;
  in0Lo = absIn0 & 65535U;
  in1Hi = absIn1 >> 16U;
  absIn0 = absIn1 & 65535U;
  productHiLo = in0Hi * absIn0;
  productLoHi = in0Lo * in1Hi;
  absIn0 *= in0Lo;
  absIn1 = 0U;
  in0Lo = (productLoHi << 16U) + absIn0;
  if (in0Lo < absIn0) {
    absIn1 = 1U;
  }

  absIn0 = in0Lo;
  in0Lo += productHiLo << 16U;
  if (in0Lo < absIn0) {
    absIn1++;
  }

  absIn0 = (((productLoHi >> 16U) + (productHiLo >> 16U)) + in0Hi * in1Hi) +
    absIn1;
  if (!((in0 == 0) || ((in1 == 0) || ((in0 > 0) == (in1 > 0))))) {
    absIn0 = ~absIn0;
    in0Lo = ~in0Lo;
    in0Lo++;
    if (in0Lo == 0U) {
      absIn0++;
    }
  }

  *ptrOutBitsHi = absIn0;
  *ptrOutBitsLo = in0Lo;
}

int32_T mul_s32_loSR(int32_T a, int32_T b, uint32_T aShift)
{
  uint32_T u32_chi;
  uint32_T u32_clo;
  mul_wide_s32(a, b, &u32_chi, &u32_clo);
  u32_clo = u32_chi << (32U - aShift) | u32_clo >> aShift;
  return (int32_T)u32_clo;
}

/*
 * System initialize for atomic system:
 *    '<S4>/Chart1'
 *    '<S4>/Chart10'
 *    '<S4>/Chart11'
 *    '<S4>/Chart12'
 *    '<S4>/Chart2'
 *    '<S4>/Chart3'
 *    '<S4>/Chart4'
 *    '<S4>/Chart5'
 *    '<S4>/Chart6'
 *    '<S4>/Chart7'
 *    ...
 */
void MYD_Chart1_Init(DW_Chart1_MYD_T *localDW)
{
  localDW->is_Imp_positioner = MYD_IN_NO_ACTIVE_CHILD;
  localDW->is_active_c1_MYD = 0U;
  localDW->is_c1_MYD = MYD_IN_NO_ACTIVE_CHILD;
}

/*
 * Output and update for atomic system:
 *    '<S4>/Chart1'
 *    '<S4>/Chart10'
 *    '<S4>/Chart11'
 *    '<S4>/Chart12'
 *    '<S4>/Chart2'
 *    '<S4>/Chart3'
 *    '<S4>/Chart4'
 *    '<S4>/Chart5'
 *    '<S4>/Chart6'
 *    '<S4>/Chart7'
 *    ...
 */
void MYD_Chart1(int32_T rtu_dal, boolean_T rtu_Start, B_Chart1_MYD_T *localB,
                DW_Chart1_MYD_T *localDW)
{
  /* Gateway: MYD/Angle2FIU1/Ntek/Chart1 */
  /* During: MYD/Angle2FIU1/Ntek/Chart1 */
  if (localDW->is_active_c1_MYD == 0U) {
    /* Entry: MYD/Angle2FIU1/Ntek/Chart1 */
    localDW->is_active_c1_MYD = 1U;

    /* Entry Internal: MYD/Angle2FIU1/Ntek/Chart1 */
    localDW->is_c1_MYD = MYD_IN_Imp_positioner;

    /* Entry Internal 'Imp_positioner': '<S5>:13' */
    /* Transition: '<S5>:3' */
    localDW->is_Imp_positioner = MYD_IN_start_work;

    /* Entry 'start_work': '<S5>:205' */
    localB->tek = 2;
    localB->Nf = false;
  } else {
    /* During 'Imp_positioner': '<S5>:13' */
    if (!rtu_Start) {
      /* Transition: '<S5>:204' */
      /* Exit Internal 'Imp_positioner': '<S5>:13' */
      localDW->is_Imp_positioner = MYD_IN_start_work;

      /* Entry 'start_work': '<S5>:205' */
      localB->tek = 2;
      localB->Nf = false;
    } else {
      switch (localDW->is_Imp_positioner) {
       case MYD_IN_comm:
        /* During 'comm': '<S5>:4' */
        /* Transition: '<S5>:8' */
        localDW->is_Imp_positioner = MYD_IN_wait_st_per;

        /* Entry 'wait_st_per': '<S5>:5' */
        localB->tek = 2;
        localB->Nf = false;
        break;

       case MYD_IN_start_work:
        /* During 'start_work': '<S5>:205' */
        if (rtu_dal > 12500) {
          /* Transition: '<S5>:206' */
          localDW->is_Imp_positioner = MYD_IN_wait_comm;
        }
        break;

       case MYD_IN_wait_comm:
        /* During 'wait_comm': '<S5>:2' */
        if (rtu_dal < -25000) {
          /* Transition: '<S5>:6' */
          localDW->is_Imp_positioner = MYD_IN_wait_st_per;

          /* Entry 'wait_st_per': '<S5>:5' */
          localB->tek = 2;
          localB->Nf = false;
        } else {
          if (rtu_dal < 12500) {
            /* Transition: '<S5>:7' */
            localB->tek = rtu_dal;
            localDW->is_Imp_positioner = MYD_IN_comm;

            /* Entry 'comm': '<S5>:4' */
            localB->Nf = true;
          }
        }
        break;

       default:
        /* During 'wait_st_per': '<S5>:5' */
        if (rtu_dal > 300000) {
          /* Transition: '<S5>:9' */
          localDW->is_Imp_positioner = MYD_IN_wait_comm;
        }
        break;
      }
    }
  }
}

/* Model step function */
void MYD_step(void)
{
  uint8_T rtb_FixPtSum1;
  uint32_T rtb_Gain2;
  int32_T rtb_Add2;
  int32_T rtb_Gain3[12];
  boolean_T rtb_UnitDelay1[1000];
  int32_T rtb_UnitDelay2[200];
  int32_T i;

  /* Outputs for Atomic SubSystem: '<Root>/MYD' */
  /* Gain: '<S1>/Gain13' incorporates:
   *  UnitDelay: '<S3>/Output'
   */
  rtb_Gain2 = 205U * MYD_DW.Output_DSTATE << 18;

  /* UnitDelay: '<S1>/Unit Delay1' */
  memcpy(&rtb_UnitDelay1[0], &MYD_DW.UnitDelay1_DSTATE[0], 1000U * sizeof
         (boolean_T));

  /* Sum: '<S2>/Add2' incorporates:
   *  Constant: '<S2>/Constant2'
   */
  rtb_Add2 = (int32_T)(rtb_Gain2 + 357913941U);
  for (i = 0; i < 6; i++) {
    /* Gain: '<S2>/Gain3' incorporates:
     *  Constant: '<S2>/Constant'
     *  Sum: '<S2>/Add'
     *  Sum: '<S2>/Add1'
     *  Sum: '<S2>/Add3'
     */
    rtb_Gain3[i] = mul_s32_loSR(15625, 1789569792 - (int32_T)
      (MYD_ConstP.Constant_Value[i] + rtb_Gain2), 26U);
    rtb_Gain3[i + 6] = mul_s32_loSR(15625, 1789569792 - ((int32_T)
      MYD_ConstP.Constant_Value[i] + rtb_Add2), 26U);
  }

  /* Chart: '<S4>/Chart7' incorporates:
   *  Constant: '<S1>/Constant56'
   */
  MYD_Chart1(rtb_Gain3[6], true, &MYD_B.sf_Chart7, &MYD_DW.sf_Chart7);

  /* Chart: '<S4>/Chart8' incorporates:
   *  Constant: '<S1>/Constant56'
   */
  MYD_Chart1(rtb_Gain3[7], true, &MYD_B.sf_Chart8, &MYD_DW.sf_Chart8);

  /* Chart: '<S4>/Chart9' incorporates:
   *  Constant: '<S1>/Constant56'
   */
  MYD_Chart1(rtb_Gain3[8], true, &MYD_B.sf_Chart9, &MYD_DW.sf_Chart9);

  /* Chart: '<S4>/Chart10' incorporates:
   *  Constant: '<S1>/Constant56'
   */
  MYD_Chart1(rtb_Gain3[9], true, &MYD_B.sf_Chart10, &MYD_DW.sf_Chart10);

  /* Chart: '<S4>/Chart11' incorporates:
   *  Constant: '<S1>/Constant56'
   */
  MYD_Chart1(rtb_Gain3[10], true, &MYD_B.sf_Chart11, &MYD_DW.sf_Chart11);

  /* Chart: '<S4>/Chart12' incorporates:
   *  Constant: '<S1>/Constant56'
   */
  MYD_Chart1(rtb_Gain3[11], true, &MYD_B.sf_Chart12, &MYD_DW.sf_Chart12);

  /* Chart: '<S4>/Chart1' incorporates:
   *  Constant: '<S1>/Constant56'
   */
  MYD_Chart1(rtb_Gain3[0], true, &MYD_B.sf_Chart1, &MYD_DW.sf_Chart1);

  /* Chart: '<S4>/Chart2' incorporates:
   *  Constant: '<S1>/Constant56'
   */
  MYD_Chart1(rtb_Gain3[1], true, &MYD_B.sf_Chart2, &MYD_DW.sf_Chart2);

  /* Chart: '<S4>/Chart3' incorporates:
   *  Constant: '<S1>/Constant56'
   */
  MYD_Chart1(rtb_Gain3[2], true, &MYD_B.sf_Chart3, &MYD_DW.sf_Chart3);

  /* Chart: '<S4>/Chart4' incorporates:
   *  Constant: '<S1>/Constant56'
   */
  MYD_Chart1(rtb_Gain3[3], true, &MYD_B.sf_Chart4, &MYD_DW.sf_Chart4);

  /* Chart: '<S4>/Chart5' incorporates:
   *  Constant: '<S1>/Constant56'
   */
  MYD_Chart1(rtb_Gain3[4], true, &MYD_B.sf_Chart5, &MYD_DW.sf_Chart5);

  /* Chart: '<S4>/Chart6' incorporates:
   *  Constant: '<S1>/Constant56'
   */
  MYD_Chart1(rtb_Gain3[5], true, &MYD_B.sf_Chart6, &MYD_DW.sf_Chart6);

  /* Sum: '<S17>/FixPt Sum1' incorporates:
   *  Constant: '<S17>/FixPt Constant'
   *  UnitDelay: '<S3>/Output'
   */
  rtb_FixPtSum1 = (uint8_T)(MYD_DW.Output_DSTATE + 1U);

  /* UnitDelay: '<S1>/Unit Delay2' */
  memcpy(&rtb_UnitDelay2[0], &MYD_DW.UnitDelay2_DSTATE[0], 200U * sizeof(int32_T));

  /* Switch: '<S18>/FixPt Switch' */
  if (rtb_FixPtSum1 > 79) {
    /* Update for UnitDelay: '<S3>/Output' incorporates:
     *  Constant: '<S18>/Constant'
     */
    MYD_DW.Output_DSTATE = 0U;
  } else {
    /* Update for UnitDelay: '<S3>/Output' */
    MYD_DW.Output_DSTATE = rtb_FixPtSum1;
  }

  /* End of Switch: '<S18>/FixPt Switch' */

  /* Update for UnitDelay: '<S1>/Unit Delay1' incorporates:
   *  Update for Inport: '<Root>/In_Boolean'
   */
  memcpy(&MYD_DW.UnitDelay1_DSTATE[0], &MYD_U.In_Boolean[0], 1000U * sizeof
         (boolean_T));

  /* Update for UnitDelay: '<S1>/Unit Delay2' incorporates:
   *  Update for Inport: '<Root>/In_Int'
   */
  memcpy(&MYD_DW.UnitDelay2_DSTATE[0], &MYD_U.In_Int[0], 200U * sizeof(int32_T));

  /* End of Outputs for SubSystem: '<Root>/MYD' */

  /* Outport: '<Root>/Out_Boolean' */
  for (i = 0; i < 10; i++) {
    MYD_Y.Out_Boolean[i] = rtb_UnitDelay1[i];
  }

  MYD_Y.Out_Boolean[10] = MYD_B.sf_Chart7.Nf;
  MYD_Y.Out_Boolean[11] = MYD_B.sf_Chart8.Nf;
  MYD_Y.Out_Boolean[12] = MYD_B.sf_Chart9.Nf;
  MYD_Y.Out_Boolean[13] = MYD_B.sf_Chart10.Nf;
  MYD_Y.Out_Boolean[14] = MYD_B.sf_Chart11.Nf;
  MYD_Y.Out_Boolean[15] = MYD_B.sf_Chart12.Nf;
  MYD_Y.Out_Boolean[16] = MYD_B.sf_Chart1.Nf;
  MYD_Y.Out_Boolean[17] = MYD_B.sf_Chart2.Nf;
  MYD_Y.Out_Boolean[18] = MYD_B.sf_Chart3.Nf;
  MYD_Y.Out_Boolean[19] = MYD_B.sf_Chart4.Nf;
  MYD_Y.Out_Boolean[20] = MYD_B.sf_Chart5.Nf;
  MYD_Y.Out_Boolean[21] = MYD_B.sf_Chart6.Nf;
  memset(&MYD_Y.Out_Boolean[22], 0, 978U * sizeof(boolean_T));

  /* End of Outport: '<Root>/Out_Boolean' */

  /* Outport: '<Root>/Out_Real' */
  MYD_Y.Out_Real[0] = 100.2F;
  MYD_Y.Out_Real[1] = 1000.89F;
  MYD_Y.Out_Real[2] = 547.2F;
  memset(&MYD_Y.Out_Real[3], 0, 197U * sizeof(real32_T));

  /* Outport: '<Root>/Out_Int' */
  for (i = 0; i < 10; i++) {
    MYD_Y.Out_Int[i] = rtb_UnitDelay2[i];
  }

  /* Outputs for Atomic SubSystem: '<Root>/MYD' */
  /* Saturate: '<S4>/Saturation7' */
  if (MYD_B.sf_Chart7.tek > 12497) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[10] = 12497;
  } else if (MYD_B.sf_Chart7.tek < 3) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[10] = 3;
  } else {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[10] = MYD_B.sf_Chart7.tek;
  }

  /* End of Saturate: '<S4>/Saturation7' */

  /* Saturate: '<S4>/Saturation8' */
  if (MYD_B.sf_Chart8.tek > 12497) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[11] = 12497;
  } else if (MYD_B.sf_Chart8.tek < 3) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[11] = 3;
  } else {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[11] = MYD_B.sf_Chart8.tek;
  }

  /* End of Saturate: '<S4>/Saturation8' */

  /* Saturate: '<S4>/Saturation9' */
  if (MYD_B.sf_Chart9.tek > 12497) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[12] = 12497;
  } else if (MYD_B.sf_Chart9.tek < 3) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[12] = 3;
  } else {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[12] = MYD_B.sf_Chart9.tek;
  }

  /* End of Saturate: '<S4>/Saturation9' */

  /* Saturate: '<S4>/Saturation10' */
  if (MYD_B.sf_Chart10.tek > 12497) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[13] = 12497;
  } else if (MYD_B.sf_Chart10.tek < 3) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[13] = 3;
  } else {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[13] = MYD_B.sf_Chart10.tek;
  }

  /* End of Saturate: '<S4>/Saturation10' */

  /* Saturate: '<S4>/Saturation11' */
  if (MYD_B.sf_Chart11.tek > 12497) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[14] = 12497;
  } else if (MYD_B.sf_Chart11.tek < 3) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[14] = 3;
  } else {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[14] = MYD_B.sf_Chart11.tek;
  }

  /* End of Saturate: '<S4>/Saturation11' */

  /* Saturate: '<S4>/Saturation12' */
  if (MYD_B.sf_Chart12.tek > 12497) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[15] = 12497;
  } else if (MYD_B.sf_Chart12.tek < 3) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[15] = 3;
  } else {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[15] = MYD_B.sf_Chart12.tek;
  }

  /* End of Saturate: '<S4>/Saturation12' */

  /* Saturate: '<S4>/Saturation1' */
  if (MYD_B.sf_Chart1.tek > 12497) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[16] = 12497;
  } else if (MYD_B.sf_Chart1.tek < 3) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[16] = 3;
  } else {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[16] = MYD_B.sf_Chart1.tek;
  }

  /* End of Saturate: '<S4>/Saturation1' */

  /* Saturate: '<S4>/Saturation2' */
  if (MYD_B.sf_Chart2.tek > 12497) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[17] = 12497;
  } else if (MYD_B.sf_Chart2.tek < 3) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[17] = 3;
  } else {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[17] = MYD_B.sf_Chart2.tek;
  }

  /* End of Saturate: '<S4>/Saturation2' */

  /* Saturate: '<S4>/Saturation3' */
  if (MYD_B.sf_Chart3.tek > 12497) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[18] = 12497;
  } else if (MYD_B.sf_Chart3.tek < 3) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[18] = 3;
  } else {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[18] = MYD_B.sf_Chart3.tek;
  }

  /* End of Saturate: '<S4>/Saturation3' */

  /* Saturate: '<S4>/Saturation4' */
  if (MYD_B.sf_Chart4.tek > 12497) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[19] = 12497;
  } else if (MYD_B.sf_Chart4.tek < 3) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[19] = 3;
  } else {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[19] = MYD_B.sf_Chart4.tek;
  }

  /* End of Saturate: '<S4>/Saturation4' */

  /* Saturate: '<S4>/Saturation5' */
  if (MYD_B.sf_Chart5.tek > 12497) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[20] = 12497;
  } else if (MYD_B.sf_Chart5.tek < 3) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[20] = 3;
  } else {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[20] = MYD_B.sf_Chart5.tek;
  }

  /* End of Saturate: '<S4>/Saturation5' */

  /* Saturate: '<S4>/Saturation6' */
  if (MYD_B.sf_Chart6.tek > 12497) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[21] = 12497;
  } else if (MYD_B.sf_Chart6.tek < 3) {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[21] = 3;
  } else {
    /* Outport: '<Root>/Out_Int' */
    MYD_Y.Out_Int[21] = MYD_B.sf_Chart6.tek;
  }

  /* End of Saturate: '<S4>/Saturation6' */
  /* End of Outputs for SubSystem: '<Root>/MYD' */

  /* Outport: '<Root>/Out_Int' */
  memset(&MYD_Y.Out_Int[22], 0, 178U * sizeof(int32_T));
}

/* Model initialize function */
void MYD_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(MYD_M, (NULL));

  /* block I/O */
  (void) memset(((void *) &MYD_B), 0,
                sizeof(B_MYD_T));

  /* states (dwork) */
  (void) memset((void *)&MYD_DW, 0,
                sizeof(DW_MYD_T));

  /* external inputs */
  (void)memset((void *)&MYD_U, 0, sizeof(ExtU_MYD_T));

  /* external outputs */
  (void) memset((void *)&MYD_Y, 0,
                sizeof(ExtY_MYD_T));

  /* SystemInitialize for Atomic SubSystem: '<Root>/MYD' */

  /* SystemInitialize for Chart: '<S4>/Chart7' */
  MYD_Chart1_Init(&MYD_DW.sf_Chart7);

  /* SystemInitialize for Chart: '<S4>/Chart8' */
  MYD_Chart1_Init(&MYD_DW.sf_Chart8);

  /* SystemInitialize for Chart: '<S4>/Chart9' */
  MYD_Chart1_Init(&MYD_DW.sf_Chart9);

  /* SystemInitialize for Chart: '<S4>/Chart10' */
  MYD_Chart1_Init(&MYD_DW.sf_Chart10);

  /* SystemInitialize for Chart: '<S4>/Chart11' */
  MYD_Chart1_Init(&MYD_DW.sf_Chart11);

  /* SystemInitialize for Chart: '<S4>/Chart12' */
  MYD_Chart1_Init(&MYD_DW.sf_Chart12);

  /* SystemInitialize for Chart: '<S4>/Chart1' */
  MYD_Chart1_Init(&MYD_DW.sf_Chart1);

  /* SystemInitialize for Chart: '<S4>/Chart2' */
  MYD_Chart1_Init(&MYD_DW.sf_Chart2);

  /* SystemInitialize for Chart: '<S4>/Chart3' */
  MYD_Chart1_Init(&MYD_DW.sf_Chart3);

  /* SystemInitialize for Chart: '<S4>/Chart4' */
  MYD_Chart1_Init(&MYD_DW.sf_Chart4);

  /* SystemInitialize for Chart: '<S4>/Chart5' */
  MYD_Chart1_Init(&MYD_DW.sf_Chart5);

  /* SystemInitialize for Chart: '<S4>/Chart6' */
  MYD_Chart1_Init(&MYD_DW.sf_Chart6);

  /* End of SystemInitialize for SubSystem: '<Root>/MYD' */
}

/* Model terminate function */
void MYD_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
