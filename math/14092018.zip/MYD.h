/*
 * File: MYD.h
 *
 * Code generated for Simulink model 'MYD'.
 *
 * Model version                  : 1.747
 * Simulink Coder version         : 8.11 (R2016b) 25-Aug-2016
 * C/C++ source code generated on : Thu Sep 13 09:31:32 2018
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_MYD_h_
#define RTW_HEADER_MYD_h_
#include <string.h>
#include <stddef.h>
#ifndef MYD_COMMON_INCLUDES_
# define MYD_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* MYD_COMMON_INCLUDES_ */

#include "MYD_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Block signals for system '<S4>/Chart1' */
typedef struct {
  int32_T tek;                         /* '<S4>/Chart1' */
  boolean_T Nf;                        /* '<S4>/Chart1' */
} B_Chart1_MYD_T;

/* Block states (auto storage) for system '<S4>/Chart1' */
typedef struct {
  uint8_T is_active_c1_MYD;            /* '<S4>/Chart1' */
  uint8_T is_c1_MYD;                   /* '<S4>/Chart1' */
  uint8_T is_Imp_positioner;           /* '<S4>/Chart1' */
} DW_Chart1_MYD_T;

/* Block signals (auto storage) */
typedef struct {
  B_Chart1_MYD_T sf_Chart9;            /* '<S4>/Chart9' */
  B_Chart1_MYD_T sf_Chart8;            /* '<S4>/Chart8' */
  B_Chart1_MYD_T sf_Chart7;            /* '<S4>/Chart7' */
  B_Chart1_MYD_T sf_Chart6;            /* '<S4>/Chart6' */
  B_Chart1_MYD_T sf_Chart5;            /* '<S4>/Chart5' */
  B_Chart1_MYD_T sf_Chart4;            /* '<S4>/Chart4' */
  B_Chart1_MYD_T sf_Chart3;            /* '<S4>/Chart3' */
  B_Chart1_MYD_T sf_Chart2;            /* '<S4>/Chart2' */
  B_Chart1_MYD_T sf_Chart12;           /* '<S4>/Chart12' */
  B_Chart1_MYD_T sf_Chart11;           /* '<S4>/Chart11' */
  B_Chart1_MYD_T sf_Chart10;           /* '<S4>/Chart10' */
  B_Chart1_MYD_T sf_Chart1;            /* '<S4>/Chart1' */
} B_MYD_T;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  int32_T UnitDelay2_DSTATE[200];      /* '<S1>/Unit Delay2' */
  uint8_T Output_DSTATE;               /* '<S3>/Output' */
  boolean_T UnitDelay1_DSTATE[1000];   /* '<S1>/Unit Delay1' */
  DW_Chart1_MYD_T sf_Chart9;           /* '<S4>/Chart9' */
  DW_Chart1_MYD_T sf_Chart8;           /* '<S4>/Chart8' */
  DW_Chart1_MYD_T sf_Chart7;           /* '<S4>/Chart7' */
  DW_Chart1_MYD_T sf_Chart6;           /* '<S4>/Chart6' */
  DW_Chart1_MYD_T sf_Chart5;           /* '<S4>/Chart5' */
  DW_Chart1_MYD_T sf_Chart4;           /* '<S4>/Chart4' */
  DW_Chart1_MYD_T sf_Chart3;           /* '<S4>/Chart3' */
  DW_Chart1_MYD_T sf_Chart2;           /* '<S4>/Chart2' */
  DW_Chart1_MYD_T sf_Chart12;          /* '<S4>/Chart12' */
  DW_Chart1_MYD_T sf_Chart11;          /* '<S4>/Chart11' */
  DW_Chart1_MYD_T sf_Chart10;          /* '<S4>/Chart10' */
  DW_Chart1_MYD_T sf_Chart1;           /* '<S4>/Chart1' */
} DW_MYD_T;

/* Constant parameters (auto storage) */
typedef struct {
  /* Computed Parameter: Constant_Value
   * Referenced by: '<S2>/Constant'
   */
  uint32_T Constant_Value[6];
} ConstP_MYD_T;

/* External inputs (root inport signals with auto storage) */
typedef struct {
  boolean_T In_Boolean[1000];          /* '<Root>/In_Boolean' */
  int32_T In_Int[200];                 /* '<Root>/In_Int' */
  real32_T In_Real[200];               /* '<Root>/In_Real' */
} ExtU_MYD_T;

/* External outputs (root outports fed by signals with auto storage) */
typedef struct {
  boolean_T Out_Boolean[1000];         /* '<Root>/Out_Boolean' */
  real32_T Out_Real[200];              /* '<Root>/Out_Real' */
  int32_T Out_Int[200];                /* '<Root>/Out_Int' */
} ExtY_MYD_T;

/* Real-time Model Data Structure */
struct tag_RTM_MYD_T {
  const char_T * volatile errorStatus;
};

/* Block signals (auto storage) */
extern B_MYD_T MYD_B;

/* Block states (auto storage) */
extern DW_MYD_T MYD_DW;

/* External inputs (root inport signals with auto storage) */
extern ExtU_MYD_T MYD_U;

/* External outputs (root outports fed by signals with auto storage) */
extern ExtY_MYD_T MYD_Y;

/* Constant parameters (auto storage) */
extern const ConstP_MYD_T MYD_ConstP;

/* Model entry point functions */
extern void MYD_initialize(void);
extern void MYD_step(void);
extern void MYD_terminate(void);

/* Real-time Model object */
extern RT_MODEL_MYD_T *const MYD_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Note that this particular code originates from a subsystem build,
 * and has its own system numbers different from the parent model.
 * Refer to the system hierarchy for this subsystem below, and use the
 * MATLAB hilite_system command to trace the generated code back
 * to the parent model.  For example,
 *
 * hilite_system('SU_in_out/MYD')    - opens subsystem SU_in_out/MYD
 * hilite_system('SU_in_out/MYD/Kp') - opens and selects block Kp
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'SU_in_out'
 * '<S1>'   : 'SU_in_out/MYD'
 * '<S2>'   : 'SU_in_out/MYD/Angle2FIU1'
 * '<S3>'   : 'SU_in_out/MYD/Counter Limited'
 * '<S4>'   : 'SU_in_out/MYD/Angle2FIU1/Ntek'
 * '<S5>'   : 'SU_in_out/MYD/Angle2FIU1/Ntek/Chart1'
 * '<S6>'   : 'SU_in_out/MYD/Angle2FIU1/Ntek/Chart10'
 * '<S7>'   : 'SU_in_out/MYD/Angle2FIU1/Ntek/Chart11'
 * '<S8>'   : 'SU_in_out/MYD/Angle2FIU1/Ntek/Chart12'
 * '<S9>'   : 'SU_in_out/MYD/Angle2FIU1/Ntek/Chart2'
 * '<S10>'  : 'SU_in_out/MYD/Angle2FIU1/Ntek/Chart3'
 * '<S11>'  : 'SU_in_out/MYD/Angle2FIU1/Ntek/Chart4'
 * '<S12>'  : 'SU_in_out/MYD/Angle2FIU1/Ntek/Chart5'
 * '<S13>'  : 'SU_in_out/MYD/Angle2FIU1/Ntek/Chart6'
 * '<S14>'  : 'SU_in_out/MYD/Angle2FIU1/Ntek/Chart7'
 * '<S15>'  : 'SU_in_out/MYD/Angle2FIU1/Ntek/Chart8'
 * '<S16>'  : 'SU_in_out/MYD/Angle2FIU1/Ntek/Chart9'
 * '<S17>'  : 'SU_in_out/MYD/Counter Limited/Increment Real World'
 * '<S18>'  : 'SU_in_out/MYD/Counter Limited/Wrap To Zero'
 */
#endif                                 /* RTW_HEADER_MYD_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
